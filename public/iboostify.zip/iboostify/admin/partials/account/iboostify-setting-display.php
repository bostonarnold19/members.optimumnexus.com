<?php

/**
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://codemage.com/
 * @since      1.0.0
 *
 * @package    Iboostify
 * @subpackage Iboostify/admin/partials
 */

?>

<script type="text/javascript">
   
</script>

<div id="iboostify-account">
    <h3>Iboostify Account</h3>
    <form action="<?= esc_url( admin_url('admin-post.php') );  ?>" method="post" role="form" id="form-iboostify-account"> 

        <input type="hidden" name="action" value="iboostify_account">

        <input type="hidden" name="type" value="update-or-create" id="type">

        <input type="hidden" name="redirect_url" value="<?= $current_url ?>">
        <div class="form-group row">
           <label for="username" class="col-sm-2 col-form-label">User Name</label>
           <div class="col-sm-10">
              <input type="text" name="username" required="" placeholder="Email" class="form-control" id="username">
           </div>
        </div>
        <div class="form-group row">
           <label for="event_id" class="col-sm-2 col-form-label">Password</label>
           <div class="col-sm-10">
              <input type="password" name="password" required="" placeholder="********" class="form-control" id="password">
           </div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>