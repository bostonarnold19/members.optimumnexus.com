<?php

/**
 * Provide a admin slider area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://codemage.com/
 * @since      1.0.0
 *
 * @package    Iboostify 
 * @subpackage Iboostify/admin/partials
 */


// get the current url, to be used to redirect later
global $wp;
$current_url = home_url(add_query_arg(null, null));

?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
</div>

<?php if ( isset($_SESSION['iboostify_message']) && isset($_SESSION['iboostify_message']['message'])) : ?>
	<div class="alert alert-<?= $_SESSION['iboostify_message']['type']; ?> alert-dismissible" role="alert">
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  <strong><?= $_SESSION['iboostify_message']['header']; ?></strong> <?= $_SESSION['iboostify_message']['message']; ?>
	</div>
<?php unset($_SESSION['iboostify_message']); endif; ?>
<!-- include Setting display -->


<?php 
// get the iboostify account
$iboostify_setting = get_iboostify_account();

if ( !$iboostify_setting ) {
	include_once ('iboostify-setting-display.php'); 
} else {
	if(date('Y-m-d H:i:s') >= $iboostify_setting['subscription_details']->expired_at) {
		echo '<div class="alert alert-danger alert-dismissible" role="alert">' .
	  		 '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' .
	  		 '<strong>Oh snap!</strong> Your subscription is expired.</div>';
		include_once ('iboostify-setting-display.php'); 
	} else {
		include_once ('iboostify-event-display.php'); 
	}
}

