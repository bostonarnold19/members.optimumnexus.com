<?php

use \Httpful\Request;
Class Octopus_REST_API
{
	protected $user;
	protected $password;
	protected $pos_user;
	protected $pos_password;
	protected $uri;
	protected $body;
	protected $header;
	protected $location;
	protected $terminal;
	protected $salesmancode;

	public function __construct()
	{
		$this->init();

		if(
			$this->uri &&
			$this->user &&
			$this->password &&
			$this->pos_user &&
			$this->pos_password &&
			$this->location &&
			$this->terminal &&
			$this->salesmancode
		) {

			add_action( 'admin_octopus_create_customer', array($this,'octopus_create_customer' ));
			add_action( 'admin_octopus_update_customer', array($this,'octopus_update_customer' ));
			add_action( 'admin_octopus_create_sales_invoice', array($this,'octopus_create_sales_invoice' ));
			add_action( 'admin_octopus_update_machine', array($this,'octopus_update_machine' ));
			add_action( 'admin_octopus_delete_machine', array($this,'octopus_delete_machine' ));
			
		}
		
	}

	private function init()
	{

		$octopus_settings 		= $this->octopus_settings();

		//set all credentials 
		$this->uri 				= @$octopus_settings['api_uri'];
		$this->user 			= @base64_encode($octopus_settings['username']);
		$this->password 		= @base64_encode($octopus_settings['password']);
		$this->pos_user 		= @$octopus_settings['pos_username'];
		$this->pos_password 	= @$octopus_settings['pos_password'];
		$this->location 		= @$octopus_settings['location'];
		$this->terminal 		= @$octopus_settings['terminal'];
		$this->salesmancode 	= @$octopus_settings['sales_man_code'];

		//set up body request
		$this->body 			= '{"UserName": "'. $this->pos_user . '","Password": "' . $this->pos_password . '"}';
		$this->header 			= $this->user . ',' . $this->password;

	}

	private function request_token()
	{
		try {

			$url  = $this->uri . 'systemAuth';
			$auth = Request::post($url)
			    ->sendsJson()
			    ->body($this->body)
			    ->addHeader('ApiAuth', $this->header)
			    ->send();

			$auth = json_decode($auth);

			if(isset($auth->access_token)) {
				return $auth->access_token;			
			}

		} catch (Exception $e) {
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'API ERROR!',
					'test_value' => 'Response: ' . $e->getMessage(),	
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
			return false;
		}
	}


	public function octopus_create_customer($user)
	{	
		$token 		= $this->request_token();

		if ($token) {
			$gender 	= '';
			$user_meta 	= get_user_meta($user->ID);

			if (isset($user_meta['title'][0]) && $user_meta['title'][0]) {
				if ($user_meta['title'][0] == 'Mr')
					$gender = 'Male';
				if ($user_meta['title'][0] == 'Ms')
					$gender = 'Female';
			}

			//add customer
			$customer_data = json_encode([
				'Address1'				=> @$user_meta['billing_address_1'][0],
				'Address2'				=> @$user_meta['billing_city'][0],
				'Address3'				=> @$user_meta['billing_state'][0],
				'Country'				=> @$user_meta['billing_country'][0],
				'PostalCode'			=> @$user_meta['billing_postcode'][0],
				'PostalCode2'			=> @$user_meta['billing_postcode'][0],
				'ShippingPostalCode'	=> @$user_meta['shipping_postcode'][0],
				'ShippingCountry'		=> @$user_meta['shipping_country'][0],
				'ShippingAddress'		=> @$user_meta['shipping_address_1'][0] . ' ' . @$user_meta['shipping_address_2'][0] . ' ' . @$user_meta['shipping_city'][0],
				'CustomerCode'			=> $user->ID,
				'IDNumber'				=> $user->ID,
				'Email'					=> $user->user_email,
				'Surname'				=> $user_meta['last_name'][0],
				'Name'					=> $user_meta['first_name'][0],
				'Sex'					=> $gender,
				'HandPhone'				=> $user_meta['mobile'][0],
				'HomePhone'				=> $user_meta['phone'][0],
				'Location'				=> $this->location 

				//octopus has no field for my machines

			]);

			$url 		= $this->uri . 'customer/add';

			$customer = Request::post($url)
			    ->sendsJson()
			    ->addHeader('ApiAuth', $this->header)
			    ->addHeader('Token', $token)
			    ->expectsHtml()
			    ->body($customer_data)
			    ->send();


			$data_response = json_decode($customer);

		    if ($data_response && isset($data_response->MembershipCode)) {
		    	update_user_meta( $user->ID, 'has_club_membership_no', sanitize_text_field(1));
		    	update_user_meta( $user->ID, 'club_membership_no', sanitize_text_field($data_response->MembershipCode));

		    	//add my machine
		    	if(isset($user_meta['my_machines'][0]) && $user_meta['my_machines'][0]) {
		    		$my_machines = unserialize($user_meta['my_machines'][0]);
		    		if ($my_machines) {
		    			foreach (unserialize($user_meta['my_machines'][0]) as $machine) {
		    				$this->add_machine($machine, $user->user_email, $data_response->MembershipCode, $token);
			    		}
			    	}
		    	}
		    }

			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Created Customer CUSTOMER_ID = ' . $user->ID,
					'test_value' => 'Response => ' . $customer  . ' Data sent => ' . $customer,
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);

		} else {
			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Created Customer CUSTOMER_ID = ' . $user->ID,
					'test_value' => 'Invalid Token',
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
		}
	}

	public function octopus_update_machine($args)
	{	
		$token 		= $this->request_token();

		if ($token) {

			$user 				= $args['user'];
			$update_user_meta 	= $args['update_user_meta'];
			$action 			= $args['action'];
			$old_machine_data 	= $args['old_machine_data'];

			if($action == 'add') {
				$this->add_machine($update_user_meta, $user->email, $user->club_membership_no, $token);
	    	} else {
	    		//delete old first
	    		$this->delete_machine($user->email, $user->club_membership_no, $old_machine_data['serial_no'], $token);
	    		//add the new data
	    		$this->add_machine($update_user_meta, $user->email, $user->club_membership_no, $token);
	    	}

		} else {
			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Created/Update My Machine CUSTOMER_ID = ' . $user->ID,
					'test_value' => 'Invalid Token',
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
		}
	}

	public function octopus_delete_machine($args)
	{	
		$token 		= $this->request_token();

		if ($token) {

			$user 			= $args['user'];
			$machine_data 	= $args['machine_data'];

			$this->delete_machine($user->email, $user->club_membership_no, $machine_data['serial_no'], $token);

		} else {
			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Delete My Machine CUSTOMER_ID = ' . $user->ID,
					'test_value' => 'Invalid Token',
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
		}
	}

	private function add_machine($machine, $user_email, $club_membership_no, $token)
	{
		if($machine['product_id'] > 0 && isset($club_membership_no) && $club_membership_no) {
			$machine_data = json_encode([
				'ProductCode'		=> get_post_meta( $machine['product_id'], '_sku', true ),
				'ProductDesc'		=> $machine['obtained_by'],
				'SerialNumber'		=> $machine['serial_no'],
				'MembershipCode'	=> $club_membership_no,
				'CustomerEmail'		=> $user_email,
				'PurchaseDate'		=> date('Y-m-d\TH:i:s',strtotime($machine['purchase_date']))
			]);

			$url = $this->uri . 'warrantyregistration/add';
			$machines = Request::post($url)
			    ->sendsJson()
			    ->addHeader('ApiAuth', $this->header)
			    ->addHeader('Token', $token)
			    ->expectsHtml()
			    ->body($machine_data)
			    ->send();
			    
			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Add My Machine CUSTOMER_ID = ' . $club_membership_no,
					'test_value' => 'Response => ' . $machines  . ' Data sent => ' . $machine_data,
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
		}
	}


	private function delete_machine($email, $club_membership_no, $serial_no, $token)
	{
		
		$url = $this->uri . "warrantyregistration/delete/email/$email/membersipcode/$club_membership_no/serialnumber/$serial_no";
		$machines = Request::delete($url)
		    ->sendsJson()
		    ->addHeader('ApiAuth', $this->header)
		    ->addHeader('Token', $token)
		    ->expectsHtml()
		    ->send();
		    
		//For Checking
		global $wpdb;
		$wpdb->insert( 
			'test_table', 
			array( 
				'test_key' => 'Transaction: Delete My Machine CUSTOMER_ID = ' . $club_membership_no,
				'test_value' => 'Response => ' . $machines  . ' Data sent => ' . $url,
				'date_created' => date('Y-m-d H:i:s')
			), 
			array( 
				'%s', 
				'%s',
				'%s'
			) 
		);
	}

	public function octopus_update_customer($user)
	{	
		$token 		= $this->request_token();

		if ($token) {
			$gender 	= '';
			$user_meta 	= get_user_meta($user->ID);

			if (isset($user_meta['title'][0]) && $user_meta['title'][0]) {
				if ($user_meta['title'][0] == 'Mr')
					$gender = 'Male';
				if ($user_meta['title'][0] == 'Ms')
					$gender = 'Female';
			}

			//add customer
			$customer_data = json_encode([
				'Address1'				=> @$user_meta['billing_address_1'][0],
				'Address2'				=> @$user_meta['billing_city'][0],
				'Address3'				=> @$user_meta['billing_state'][0],
				'Country'				=> @$user_meta['billing_country'][0],
				'PostalCode'			=> @$user_meta['billing_postcode'][0],
				'PostalCode2'			=> @$user_meta['billing_postcode'][0],
				'ShippingPostalCode'	=> @$user_meta['shipping_postcode'][0],
				'ShippingCountry'		=> @$user_meta['shipping_country'][0],
				'ShippingAddress'		=> @$user_meta['shipping_address_1'][0] . ' ' . @$user_meta['shipping_address_2'][0] . ' ' . @$user_meta['shipping_city'][0],
				'CustomerCode'			=> $user->ID,
				'IDNumber'				=> $user->ID,
				'Email'					=> $user->user_email,
				'Surname'				=> $user_meta['last_name'][0],
				'Name'					=> $user_meta['first_name'][0],
				'Sex'					=> $gender,
				'HandPhone'				=> $user_meta['mobile'][0],
				'HomePhone'				=> $user_meta['phone'][0],
				'Location'				=> $this->location 

				//octopus has no field for my machines

			]);

			$url 		= $this->uri . 'customer/add'; 

			$customer = Request::post($url)
			    ->sendsJson()
			    ->addHeader('ApiAuth', $this->header)
			    ->addHeader('Token', $token)
			    ->expectsHtml()
			    ->body($customer_data)
			    ->send();

		    $data_response = json_decode($customer);

		    if ($data_response && isset($data_response->MembershipCode)) {
		    	update_user_meta( $user->ID, 'has_club_membership_no', sanitize_text_field(1));
		    	update_user_meta( $user->ID, 'club_membership_no', sanitize_text_field($data_response->MembershipCode));
		    }

			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Update Customer CUSTOMER_ID = ' . $user->ID,
					'test_value' => 'Response => ' . $customer,
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);

		}  else {
			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Update Customer CUSTOMER_ID = ' . $user->ID,
					'test_value' => 'Invalid Token',
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
		}
	}

	public function octopus_create_sales_invoice($order_id)
	{	

		$token 		= $this->request_token();

		if ($token) {
			//Process Order Data

			$order = wc_get_order( $order_id );
			// The Order data
			$order_data 				= $order->get_data(); 

			//order product details
			$order_product 				= [];

			$total_discount_amount 		= $order_data['discount_total'];
			$computed_discount_amount 	= 0;
			$counter 					= 1;
			$count 						= count($order->get_items());

			foreach ( $order->get_items() as $key => $item ) {

			    //get product details
			    
			    if($item['variation_id']) {
			        $_product = wc_get_product( $item['variation_id'] );
			    } else {
			        $_product = wc_get_product( $item['product_id'] );
			    }


			    $discount_per_item                          = $item->get_subtotal() - $item->get_total();

			    //last loop override the last discount amount into remaining amount discount amount (due to round issue)
			    if ($counter == $count) {
			       $discount_per_item = round($total_discount_amount - $computed_discount_amount,2);
			    }

			    $computed_discount_amount					+= $discount_per_item;
			    $item_net_amount                            = $item['subtotal'] - $discount_per_item;
			    $taxAmount                                  = $item_net_amount-($item_net_amount/1.12);
			    $discount_percentage                        = ($discount_per_item / $item['subtotal']) * 100;

			    $order_product[$key]['ProductCode']         = $_product->get_sku();
			    $order_product[$key]['UnitCost']            = 0;
			    $order_product[$key]['RetailSalesPrice']    = $_product->get_price();
			    $order_product[$key]['TotalDiscount']       = round($discount_per_item,2);
			    $order_product[$key]['DiscountPercentage']  = round($discount_percentage,2);
			    $order_product[$key]['TaxAmount']           = round($taxAmount,2);
			    $order_product[$key]['TaxPercentage']       = 12; //constant
			    $order_product[$key]['ItemNetAmount']       = $item_net_amount;
			    $order_product[$key]['Quantity']            = $item['quantity'];

			    $counter++;

			}

	        $order_product_item = [];
	        foreach ($order_product as $key => $value) {
	            $order_product_item[] = $value;
	        }

	        $paymentMode = 'Cash';
	        if( $order->get_payment_method() == 'ppg') {
	        	$paymentMode = 'Visa';
	        } else if ($order->get_payment_method() == 'bacs') {
	        	$paymentMode = 'Bank Transfer';
	        }

	        //date
	        $date_created = $order_data['date_created'];
	        $date_created->modify('-8 hour');

	        //tax amount
	        $net_sale_amount = $order->get_subtotal() - $order_data['discount_total'];
	        $taxAmount = $net_sale_amount-($net_sale_amount/1.12);
			$invoice_data = json_encode([
			   "InvoiceDate" 				=> $date_created->format('Y-m-d\TH:i:s'),
			   "CustomerCode" 				=> $order_data['customer_id'],
			   "TotalDiscountAmount" 		=> $order_data['discount_total'],
			   "InvoiceNumber" 				=> $order_id,
			   "InvoiceType" 				=> "SALES",
			   "Location" 					=> $this->location,
			   "NetSalesAmount" 			=> $net_sale_amount,
			   // "RoundOffAmount" 			=> 0,
			   "CashierCode" 				=>  "admin",
			   "Status" 					=> 1,
			   "TaxAmount" 					=> round($taxAmount,2),
			   "TaxPercentage" 				=> 12, //12% constant
			   // "VoidBy" 					=> null,
			   // "VoidDate" 				=> null,
			   // "VoidReason" 				=> null,
			   // "WholeReceiptDiscount" 	=> 0,
			   "Terminal" 					=> $this->terminal, 
			   "SalesmanCode" 				=> $this->salesmancode, 
			   "Remark" 					=> $order->get_customer_note(),
			   'DeliveryName'				=> $order_data['shipping']['first_name'] . ' ' . $order_data['shipping']['last_name'],
			   "DeliveryAddress" 			=> $order_data['shipping']['address_1'],
			   'DeliveryAddress2'			=> $order_data['shipping']['address_2'],
			   'DeliveryCity'				=> $order_data['shipping']['city'],
			   'DeliveryState'				=> $order_data['shipping']['state'],
			   'DeliveryCountry'			=> $order_data['shipping']['country'],
			   'DeliveryPostalCode'			=> @$order_data['shipping']['shipping_postcode'],
			   'OrderStatus'				=> 1,
			   // "TotalNoOfSalesman" 			=> 1,
			   // "PointsEarned" 				=> 0,
			   "CurrencyCode" 				=> $order_data['currency'],
			   "IsTaxExclusive" 			=> 0,
			   "ShippingCost" 				=> $order_data['shipping_total'],
			   // "PaymentPromoDiscount" 	=> null,
			   "CustomerName" 				=> $order_data['billing']['first_name'] . ' ' . $order_data['billing']['last_name'],
			   "CustomerEmail" 				=> $order_data['billing']['email'],
			   "CustomerPhone" 				=> $order_data['billing']['phone'],
			   "CustomerAddress" 			=> $order_data['billing']['address_1'] . ' ' . $order_data['billing']['address_2'] . ' ' . $order_data['billing']['city'],
			   // "OrginalInvoiceNumber" 	=> " ",
			   // "OrginalSalesOrderNumber" => " ",

			   "InvoiceItems" 				=> $order_product_item, //array
			   "PaymentItems" => [
			      [
			         "Amount" 				=> $order->get_total(),
			         "PaymentDate" 			=> $date_created->format('Y-m-d\TH:i:s'),
			         "PaymentMode" 			=> $paymentMode,
			         "Remark"				=> $order->get_payment_method_title(),
			         "CurrencyCode" 		=> $order_data['currency'],
			         // "CustomerPoint" 		=> 0,
			         // "DocumentNumber" 		=> null
			      ]
			   ]

			]);

			$url 		= $this->uri . 'invoice/add'; 

			$invoice = Request::post($url)
			    ->sendsJson()
			    ->addHeader('ApiAuth', $this->header)
			    ->addHeader('Token', $token)
			    ->expectsHtml()
			    ->body($invoice_data)
			    ->send();

			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Created Invoice ORDER_ID = ' . $order_id,
					'test_value' => 'Response => '.$invoice . ' Data sent => ' . $invoice_data,
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);

		} else {
			//For Checking
			global $wpdb;
			$wpdb->insert( 
				'test_table', 
				array( 
					'test_key' => 'Transaction: Created Invoice ORDER_ID = ' . $order_id,
					'test_value' => 'Invalid Token',
					'date_created' => date('Y-m-d H:i:s')
				), 
				array( 
					'%s', 
					'%s',
					'%s'
				) 
			);
		}
	}

	private function octopus_settings() 
	{


		$octopus_settings = get_option('octopus_settings_option_name');

		if ( !$octopus_settings )
			return [];
		
		return $octopus_settings;

	}	

}