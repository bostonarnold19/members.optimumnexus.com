<style type="text/css">
	@charset "utf-8";

	::-webkit-scrollbar {
		width: 7px
	}
	::-webkit-scrollbar-track {
		background-color: #eee;
		border-radius: 0px
	}
	::-webkit-scrollbar-track-piece {
		opacity: 1
	}
	::-webkit-scrollbar-thumb {
		border-radius: 0px;
		background-color: #aaa
	}
	::-moz-selection {
		color: #fff;
		background: #1AAB8A
	}
	::selection {
		color: #fff;
		background: #1AAB8A
	}
	@keyframes pular {
		from {
			-webkit-transform: scale(1);
			transform: scale(1)
		}
		50% {
			-webkit-transform: scale(1.1);
			transform: scale(1.1)
		}
		to {
			-webkit-transform: scale(1);
			transform: scale(1)
		}
	}
	.txt-destaque1 {
	    font-weight: 800;
	    color: #B22222;
	    font-family: 'Ubuntu', sans-serif;
	}
	.body-modalx {
		opacity: 0; visibility: hidden; display: none;
		max-width: 700px;
		background-color: rgba(255, 255, 255, 0.95);
		padding: 15px 15px 15px 15px;
		border-radius: 2px;
		-webkit-box-shadow: 0px 0px 25px 6px rgba(0, 0, 0, 0.32);
		-moz-box-shadow: 0px 0px 25px 6px rgba(0, 0, 0, 0.32);
		box-shadow: 0px 0px 25px 6px rgba(0, 0, 0, 0.32)
	}

	#modalx-fastFade {
		-webkit-animation-name: fade-Out;
		animation-name: fade-Out;
		-webkit-animation-duration: 0.3s;
		animation-duration: 0.3s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fade-Out {
		0% {
			opacity: 1
		}
		100% {
			opacity: 0
		}
	}
	@keyframes fade-Out {
		0% {
			opacity: 1
		}
		100% {
			opacity: 0
		}
	}
	.popup_visible #modalx-fastFade {
		-webkit-animation-name: fastFade;
		animation-name: fastFade;
		-webkit-animation-duration: 0.3s;
		animation-duration: 0.3s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fastFade {
		0% {
			opacity: 0
		}
		100% {
			opacity: 1
		}
	}
	@keyframes fastFade {
		0% {
			opacity: 0
		}
		100% {
			opacity: 1
		}
	}
	/*/*/

	/**/

	#modalx-fadeScale {
		-webkit-transform: scale(0);
		-moz-transform: scale(0);
		-ms-transform: scale(0);
		transform: scale(0)
	}
	.popup_visible #modalx-fadeScale {
		-webkit-transform: scale(1);
		-moz-transform: scale(1);
		-ms-transform: scale(1);
		transform: scale(1)
	}
	/*/*/

	/**/

	#modalx-fadeOutUp {
		-webkit-animation-name: fadeOutUpBig;
		animation-name: fadeOutUpBig;
		-webkit-animation-duration: 0.5s;
		animation-duration: 0.5s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fadeOutUpBig {
		0% {
			opacity: 1
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(0, -2000px, 0);
			transform: translate3d(0, -2000px, 0)
		}
	}
	@keyframes fadeOutUpBig {
		0% {
			opacity: 1
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(0, -2000px, 0);
			transform: translate3d(0, -2000px, 0)
		}
	}
	.popup_visible #modalx-fadeOutUp {
		-webkit-animation-name: fadeInUpBig;
		animation-name: fadeInUpBig;
		-webkit-animation-duration: 0.3s;
		animation-duration: 0.3s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fadeInUpBig {
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, 2000px, 0);
			transform: translate3d(0, 2000px, 0)
		}
		100% {
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes fadeInUpBig {
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, 2000px, 0);
			transform: translate3d(0, 2000px, 0)
		}
		100% {
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}
	}
	/*/*/

	/**/

	#modalx-slowFade {
		-webkit-animation-name: fastFadeOut;
		animation-name: fastFadeOut;
		-webkit-animation-duration: 0.6s;
		animation-duration: 0.6s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fastFadeOut {
		0% {
			opacity: 1
		}
		100% {
			opacity: 0
		}
	}
	@keyframes fastFadeOut {
		0% {
			opacity: 1
		}
		100% {
			opacity: 0
		}
	}
	.popup_visible #modalx-slowFade {
		-webkit-animation-name: fastFade;
		animation-name: fastFade;
		-webkit-animation-duration: 0.9s;
		animation-duration: 0.9s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fastFade {
		0% {
			opacity: 0
		}
		100% {
			opacity: 1
		}
	}
	@keyframes fastFade {
		0% {
			opacity: 0
		}
		100% {
			opacity: 1
		}
	}
	}
	/*/*/

	/**/

	#modalx-lightSpeed {
		-webkit-animation-name: lightSpeedOut;
		animation-name: lightSpeedOut;
		-webkit-animation-duration: 0.3s;
		animation-duration: 0.3s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	0%,
	60%,
	75%,
	90%,
	100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
		transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
	}
	@-webkit-keyframes lightSpeedOut {
		20% {
			opacity: 1;
			-webkit-transform: translate3d(-20px, 0, 0);
			transform: translate3d(-20px, 0, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(2000px, 0, 0);
			transform: translate3d(2000px, 0, 0)
		}
	}
	@keyframes lightSpeedOut {
		20% {
			opacity: 1;
			-webkit-transform: translate3d(-20px, 0, 0);
			transform: translate3d(-20px, 0, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(2000px, 0, 0);
			transform: translate3d(2000px, 0, 0)
		}
	}
	.popup_visible #modalx-lightSpeed {
		-webkit-animation-name: bounceInLeft;
		animation-name: bounceInLeft;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes bounceInLeft {
		0%, 60%, 75%, 90%, 100% {
			-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
			transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(-3000px, 0, 0);
			transform: translate3d(-3000px, 0, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(25px, 0, 0);
			transform: translate3d(25px, 0, 0)
		}
		75% {
			-webkit-transform: translate3d(-10px, 0, 0);
			transform: translate3d(-10px, 0, 0)
		}
		90% {
			-webkit-transform: translate3d(5px, 0, 0);
			transform: translate3d(5px, 0, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes bounceInLeft {
		0%,
		60%,
		75%,
		90%,
		100% {
			-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
			transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(-3000px, 0, 0);
			transform: translate3d(-3000px, 0, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(25px, 0, 0);
			transform: translate3d(25px, 0, 0)
		}
		75% {
			-webkit-transform: translate3d(-10px, 0, 0);
			transform: translate3d(-10px, 0, 0)
		}
		90% {
			-webkit-transform: translate3d(5px, 0, 0);
			transform: translate3d(5px, 0, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	/*/*/

	/**/

	#modalx-slideDown {
		-webkit-animation-name: bounceOut;
		animation-name: bounceOut;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-duration: 0.7s;
		animation-duration: 0.7s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes bounceOut {
		20% {
			-webkit-transform: scale3d(.9, .9, .9);
			transform: scale3d(.9, .9, .9)
		}
		50%,
		55% {
			opacity: 1;
			-webkit-transform: scale3d(1.1, 1.1, 1.1);
			transform: scale3d(1.1, 1.1, 1.1)
		}
		100% {
			opacity: 0;
			-webkit-transform: scale3d(.3, .3, .3);
			transform: scale3d(.3, .3, .3)
		}
	}
	@keyframes bounceOut {
		20% {
			-webkit-transform: scale3d(.9, .9, .9);
			transform: scale3d(.9, .9, .9)
		}
		50%,
		55% {
			opacity: 1;
			-webkit-transform: scale3d(1.1, 1.1, 1.1);
			transform: scale3d(1.1, 1.1, 1.1)
		}
		100% {
			opacity: 0;
			-webkit-transform: scale3d(.3, .3, .3);
			transform: scale3d(.3, .3, .3)
		}
	}
	.popup_visible #modalx-slideDown {
		-webkit-animation-name: slideInDown;
		animation-name: slideInDown;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes slideInDown {
		0% {
			-webkit-transform: translateY(-100%);
			transform: translateY(-100%);
			visibility: visible
		}
		100% {
			-webkit-transform: translateY(0);
			transform: translateY(0)
		}
	}
	@keyframes slideInDown {
		0% {
			-webkit-transform: translateY(-100%);
			transform: translateY(-100%);
			visibility: visible
		}
		100% {
			-webkit-transform: translateY(0);
			transform: translateY(0)
		}
	}
	/*/*/

	/**/

	#modalx-slideUp {
		-webkit-animation-name: bounceOut;
		animation-name: bounceOut;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-duration: 0.7s;
		animation-duration: 0.7s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes bounceOut {
		20% {
			-webkit-transform: scale3d(.9, .9, .9);
			transform: scale3d(.9, .9, .9)
		}
		50%,
		55% {
			opacity: 1;
			-webkit-transform: scale3d(1.1, 1.1, 1.1);
			transform: scale3d(1.1, 1.1, 1.1)
		}
		100% {
			opacity: 0;
			-webkit-transform: scale3d(.3, .3, .3);
			transform: scale3d(.3, .3, .3)
		}
	}
	@keyframes bounceOut {
		20% {
			-webkit-transform: scale3d(.9, .9, .9);
			transform: scale3d(.9, .9, .9)
		}
		50%,
		55% {
			opacity: 1;
			-webkit-transform: scale3d(1.1, 1.1, 1.1);
			transform: scale3d(1.1, 1.1, 1.1)
		}
		100% {
			opacity: 0;
			-webkit-transform: scale3d(.3, .3, .3);
			transform: scale3d(.3, .3, .3)
		}
	}
	.popup_visible #modalx-slideUp {
		-webkit-animation-name: fadeInUp;
		animation-name: fadeInUp;
		-webkit-animation-duration: 0.5s;
		animation-duration: 0.5s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fadeInUp {
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, 100%, 0);
			transform: translate3d(0, 100%, 0)
		}
		100% {
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes fadeInUp {
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, 100%, 0);
			transform: translate3d(0, 100%, 0)
		}
		100% {
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}
	}
	/*/*/

	/**/

	#modalx-flipOut {
		-webkit-animation-name: flipOutX;
		animation-name: flipOutX;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-backface-visibility: visible !important;
		backface-visibility: visible !important;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes flipOutX {
		0% {
			-webkit-transform: perspective(900px);
			transform: perspective(900px)
		}
		30% {
			-webkit-transform: perspective(900px) rotate3d(1, 0, 0, -20deg);
			transform: perspective(900px) rotate3d(1, 0, 0, -20deg);
			opacity: 1
		}
		100% {
			-webkit-transform: perspective(900px) rotate3d(1, 0, 0, 90deg);
			transform: perspective(900px) rotate3d(1, 0, 0, 90deg);
			opacity: 0
		}
	}
	@keyframes flipOutX {
		0% {
			-webkit-transform: perspective(900px);
			transform: perspective(900px)
		}
		30% {
			-webkit-transform: perspective(900px) rotate3d(1, 0, 0, -20deg);
			transform: perspective(900px) rotate3d(1, 0, 0, -20deg);
			opacity: 1
		}
		100% {
			-webkit-transform: perspective(900px) rotate3d(1, 0, 0, 90deg);
			transform: perspective(900px) rotate3d(1, 0, 0, 90deg);
			opacity: 0
		}
	}
	.popup_visible #modalx-flipOut {
		-webkit-backface-visibility: visible !important;
		backface-visibility: visible !important;
		-webkit-animation-name: flipInY;
		animation-name: flipInY;
		-webkit-animation-duration: 0.5s;
		animation-duration: 0.5s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes flipInY {
		0% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, 180deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, 180deg);
			-webkit-transition-timing-function: ease-in;
			transition-timing-function: ease-in;
			opacity: 0
		}
		40% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, -20deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, -20deg);
			-webkit-transition-timing-function: ease-in;
			transition-timing-function: ease-in
		}
		60% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, 10deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, 10deg);
			opacity: 1
		}
		80% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, -5deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, -5deg)
		}
		100% {
			-webkit-transform: perspective(1200px);
			transform: perspective(1200px)
		}
	}
	@keyframes flipInY {
		0% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, 180deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, 180deg);
			-webkit-transition-timing-function: ease-in;
			transition-timing-function: ease-in;
			opacity: 0
		}
		40% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, -20deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, -20deg);
			-webkit-transition-timing-function: ease-in;
			transition-timing-function: ease-in
		}
		60% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, 10deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, 10deg);
			opacity: 1
		}
		80% {
			-webkit-transform: perspective(1200px) rotate3d(0, 1, 0, -5deg);
			transform: perspective(1200px) rotate3d(0, 1, 0, -5deg)
		}
		100% {
			-webkit-transform: perspective(1200px);
			transform: perspective(1200px)
		}
	}
	/*/*/

	/**/

	#modalx-zoomIn {
		-webkit-animation-name: bounceOutDown;
		animation-name: bounceOutDown;
		-webkit-animation-duration: 0.9s;
		animation-duration: 0.9s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes bounceOutDown {
		20% {
			-webkit-transform: translate3d(0, 10px, 0);
			transform: translate3d(0, 10px, 0)
		}
		40%,
		45% {
			opacity: 1;
			-webkit-transform: translate3d(0, -20px, 0);
			transform: translate3d(0, -20px, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(0, 2000px, 0);
			transform: translate3d(0, 2000px, 0)
		}
	}
	@keyframes bounceOutDown {
		20% {
			-webkit-transform: translate3d(0, 10px, 0);
			transform: translate3d(0, 10px, 0)
		}
		40%,
		45% {
			opacity: 1;
			-webkit-transform: translate3d(0, -20px, 0);
			transform: translate3d(0, -20px, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(0, 2000px, 0);
			transform: translate3d(0, 2000px, 0)
		}
	}
	.popup_visible #modalx-zoomIn {
		-webkit-animation-name: zoomInDown;
		animation-name: zoomInDown;
		-webkit-animation-duration: 1s;
		animation-duration: 1s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes zoomInDown {
		0% {
			opacity: 0;
			-webkit-transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);
			transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);
			-webkit-animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);
			animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190)
		}
		60% {
			opacity: 1;
			-webkit-transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);
			transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);
			-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);
			animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1)
		}
	}
	@keyframes zoomInDown {
		0% {
			opacity: 0;
			-webkit-transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);
			transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);
			-webkit-animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);
			animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190)
		}
		60% {
			opacity: 1;
			-webkit-transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);
			transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);
			-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);
			animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1)
		}
	}
	/*/*/

	/**/

	#modalx-slideHard {
		-webkit-animation-name: zoomOutDown;
		animation-name: zoomOutDown;
		-webkit-animation-duration: 0.7s;
		animation-duration: 0.7s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes zoomOutDown {
		40% {
			opacity: 1;
			-webkit-transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);
			transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);
			-webkit-animation-timing-function: cubic-bezier(0.950, 0.555, 0.675, 0.190);
			animation-timing-function: cubic-bezier(0.950, 0.555, 0.675, 0.190)
		}
		100% {
			opacity: 0;
			-webkit-transform: scale3d(.1, .1, .1) translate3d(0, 2000px, 0);
			transform: scale3d(.1, .1, .1) translate3d(0, 2000px, 0);
			-webkit-transform-origin: center bottom;
			transform-origin: center bottom;
			-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);
			animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1)
		}
	}
	@keyframes zoomOutDown {
		40% {
			opacity: 1;
			-webkit-transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);
			transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);
			-webkit-animation-timing-function: cubic-bezier(0.950, 0.055, 0.675, 0.190);
			animation-timing-function: cubic-bezier(0.950, 0.055, 0.675, 0.190)
		}
		100% {
			opacity: 0;
			-webkit-transform: scale3d(.1, .1, .1) translate3d(0, 2000px, 0);
			transform: scale3d(.1, .1, .1) translate3d(0, 2000px, 0);
			-webkit-transform-origin: center bottom;
			transform-origin: center bottom;
			-webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);
			animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1)
		}
	}
	.popup_visible #modalx-slideHard {
		-webkit-animation-name: bounceInDown;
		animation-name: bounceInDown;
		-webkit-animation-duration: 0.6s;
		animation-duration: 0.6s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes bounceInDown {
		0%, 60%, 75%, 90%, 100% {
			-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
			transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, -3000px, 0);
			transform: translate3d(0, -3000px, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(0, 15px, 0);
			transform: translate3d(0, 15px, 0)
		}
		75% {
			-webkit-transform: translate3d(0, -10px, 0);
			transform: translate3d(0, -10px, 0)
		}
		90% {
			-webkit-transform: translate3d(0, 5px, 0);
			transform: translate3d(0, 5px, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes bounceInDown {
		0%,
		60%,
		75%,
		90%,
		100% {
			-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
			transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, -3000px, 0);
			transform: translate3d(0, -3000px, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(0, 15px, 0);
			transform: translate3d(0, 15px, 0)
		}
		75% {
			-webkit-transform: translate3d(0, -10px, 0);
			transform: translate3d(0, -10px, 0)
		}
		90% {
			-webkit-transform: translate3d(0, 5px, 0);
			transform: translate3d(0, 5px, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	/*/*/

	/**/

	#modalx-rollIn {
		-webkit-animation-name: fadeOutRightBig;
		animation-name: fadeOutRightBig;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes fadeOutRightBig {
		from {
			opacity: 1
		}
		to {
			opacity: 0;
			-webkit-transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 220deg);
			transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 220deg)
		}
	}
	@keyframes fadeOutRightBig {
		from {
			opacity: 1
		}
		to {
			opacity: 0;
			-webkit-transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 220deg);
			transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 220deg)
		}
	}
	.popup_visible #modalx-rollIn {
		-webkit-animation-name: rollIn;
		animation-name: rollIn;
		-webkit-animation-duration: 0.3s;
		animation-duration: 0.3s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes rollIn {
		from {
			opacity: 0;
			-webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -220deg);
			transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -220deg)
		}
		to {
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes rollIn {
		from {
			opacity: 0;
			-webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -220deg);
			transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -220deg)
		}
		to {
			opacity: 1;
			-webkit-transform: none;
			transform: none
		}
	}
	/*/*/

	/**/

	#modalx-popBounce {
		-webkit-animation-name: popBounceOffSet;
		animation-name: popBounceOffSet;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	0%,
	60%,
	75%,
	90%,
	100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
		transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
	}
	@-webkit-keyframes popBounceOffSet {
		20% {
			opacity: 1;
			-webkit-transform: translate3d(-20px, 0, 0);
			transform: translate3d(-20px, 0, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(2000px, 0, 0);
			transform: translate3d(2000px, 0, 0)
		}
	}
	@keyframes popBounceOffSet {
		20% {
			opacity: 1;
			-webkit-transform: translate3d(-20px, 0, 0);
			transform: translate3d(-20px, 0, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(2000px, 0, 0);
			transform: translate3d(2000px, 0, 0)
		}
	}
	.popup_visible #modalx-popBounce {
		-webkit-animation-name: popBounceOut;
		animation-name: popBounceOut;
		-webkit-animation-duration: 0.6s;
		animation-duration: 0.6s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes popBounceOut {
		0%, 60%, 75%, 90%, 100% {
			-webkit-transition-timing-function: cubic-bezier(0.115, 0.610, 0.055, 1.000);
			transition-timing-function: cubic-bezier(0.115, 0.610, 0.055, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, -3000px, 0);
			transform: translate3d(0, -3000px, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(0, 25px, 0);
			transform: translate3d(0, 25px, 0)
		}
		75% {
			-webkit-transform: translate3d(0, -10px, 0);
			transform: translate3d(0, -10px, 0)
		}
		90% {
			-webkit-transform: translate3d(0, 5px, 0);
			transform: translate3d(0, 5px, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes popBounceOut {
		0%,
		60%,
		75%,
		90%,
		100% {
			-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
			transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, -3000px, 0);
			transform: translate3d(0, -3000px, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(0, 25px, 0);
			transform: translate3d(0, 25px, 0)
		}
		75% {
			-webkit-transform: translate3d(0, -10px, 0);
			transform: translate3d(0, -10px, 0)
		}
		90% {
			-webkit-transform: translate3d(0, 5px, 0);
			transform: translate3d(0, 5px, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	/*/*/

	/**/

	#modalx-howUse {
		-webkit-animation-name: howUseOut;
		animation-name: howUseOut;
		-webkit-animation-duration: 0.4s;
		animation-duration: 0.4s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	0%,
	60%,
	75%,
	90%,
	100% {
		-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
		transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
	}
	@-webkit-keyframes howUseOut {
		20% {
			opacity: 1;
			-webkit-transform: translate3d(-20px, 0, 0);
			transform: translate3d(-20px, 0, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(2000px, 0, 0);
			transform: translate3d(2000px, 0, 0)
		}
	}
	@keyframes howUseOut {
		20% {
			opacity: 1;
			-webkit-transform: translate3d(-20px, 0, 0);
			transform: translate3d(-20px, 0, 0)
		}
		100% {
			opacity: 0;
			-webkit-transform: translate3d(2000px, 0, 0);
			transform: translate3d(2000px, 0, 0)
		}
	}
	.popup_visible #modalx-howUse {
		-webkit-animation-name: howUseIn;
		animation-name: howUseIn;
		-webkit-animation-duration: 0.6s;
		animation-duration: 0.6s;
		-webkit-animation-fill-mode: both;
		animation-fill-mode: both
	}
	@-webkit-keyframes howUseIn {
		0%, 60%, 75%, 90%, 100% {
			-webkit-transition-timing-function: cubic-bezier(0.115, 0.610, 0.055, 1.000);
			transition-timing-function: cubic-bezier(0.115, 0.610, 0.055, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, -3000px, 0);
			transform: translate3d(0, -3000px, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(0, 25px, 0);
			transform: translate3d(0, 25px, 0)
		}
		75% {
			-webkit-transform: translate3d(0, -10px, 0);
			transform: translate3d(0, -10px, 0)
		}
		90% {
			-webkit-transform: translate3d(0, 5px, 0);
			transform: translate3d(0, 5px, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}
	@keyframes howUseIn {
		0%,
		60%,
		75%,
		90%,
		100% {
			-webkit-transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);
			transition-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000)
		}
		0% {
			opacity: 0;
			-webkit-transform: translate3d(0, -3000px, 0);
			transform: translate3d(0, -3000px, 0)
		}
		60% {
			opacity: 1;
			-webkit-transform: translate3d(0, 25px, 0);
			transform: translate3d(0, 25px, 0)
		}
		75% {
			-webkit-transform: translate3d(0, -10px, 0);
			transform: translate3d(0, -10px, 0)
		}
		90% {
			-webkit-transform: translate3d(0, 5px, 0);
			transform: translate3d(0, 5px, 0)
		}
		100% {
			-webkit-transform: none;
			transform: none
		}
	}

	/* boostraps*/
	.hidden {
		display: none !important;
	}
	.body-modalx {
	    font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif !important;
	    font-size: 1rem !important;
	    font-weight: 400 !important;
	    line-height: 1.5 !important;
	    color: #212529 !important;
	}
	.body-modalx .text-center {
	    text-align: center !important !important;
	}
	.body-modalx .h1, .body-modalx h1 {
	    font-size: 2.5rem !important;
	}
	.body-modalx .h2, .body-modalx h2 {
	    font-size: 2rem !important;
	}
	.body-modalx h3, .body-modalx .h3 {
	    font-size: 1.75rem !important;
	}
	.body-modalx h4, .body-modalx .h4 {
	    font-size: 1.5rem
	}
	.body-modalx .h5, .body-modalx h5 {
	    font-size: 1.25rem !important;
	}
	.body-modalx  p {
	    margin-top: 0 !important;
	    margin-bottom: 1rem !important;
	}
	.body-modalx h1, .body-modalx h2, .body-modalx h3, .body-modalx h4, .body-modalx h5, .body-modalx h6,
	.body-modalx .h1, .body-modalx .h2, .body-modalx .h3, .body-modalx .h4, .body-modalx .h5, .body-modalx .h6 {
	    margin-bottom: .5rem !important;
	    font-family: inherit !important;
	    font-weight: 500 !important;
	    line-height: 1.1 !important;
	    color: inherit !important;
	    text-transform: none !important;
	}
	.body-modalx h1, .body-modalx h2, .body-modalx h3, .body-modalx h4, .body-modalx h5, .body-modalx h6,
	.body-modalx .h1, .body-modalx .h2, .body-modalx .h3, .body-modalx .h4, .body-modalx .h5, .body-modalx .h6 {
	    margin-top: 0 !important;
	    margin-bottom: .5rem !important;
	}
	.body-modalx .fa {
	    display: inline-block !important;
	    font: normal normal normal 14px/1 FontAwesome !important;
	    font-size: inherit !important;
	    text-rendering: auto !important;
	    -webkit-font-smoothing: antialiased !important;
	    -moz-osx-font-smoothing: grayscale !important;
	}

	.body-modalx hr {
	    margin-top: 1rem !important;
	    margin-bottom: 1rem !important;
	    border: 0 !important;
	        border-top-width: 0px !important;
	        border-top-style: none !important;
	        border-top-color: currentcolor !important;
	    border-top: 1px solid rgba(0,0,0,.1) !important;
	        border-top-width: 1px !important;
	        border-top-style: solid !important;
	        border-top-color: rgba(0, 0, 0, 0.1) !important;
	}
	@media(max-width: 12000px) {
		.body-modalx .container {
		    max-width: 1140px !important;
		}
	}
	@media(max-width: 992px) {
		.body-modalx .container {
		    max-width: 960px !important;
		}
	}
	@media(max-width: 768px) {
		.body-modalx .container {
		    max-width: 720px !important;
		}
	}

	@media(max-width: 576px) {
		.body-modalx .container {
		    max-width: 540px !important;
		}
	}

	.body-modalx .container {
	    margin-right: auto !important;
	    margin-left: auto !important;
	    padding-right: 15px !important;
	    padding-left: 15px !important;
	    width: 100% !important;
	}

	.body-modalx .form-group {
	    margin-bottom: 1rem !important;
	}

	.body-modalx .row {
	    display: -ms-flexbox !important;
	    display: flex !important;
	    -ms-flex-wrap: wrap !important;
	    flex-wrap: wrap !important;
	    margin-right: -15px !important;
	    margin-left: -15px !important;
	}

	.body-modalx .col, .body-modalx .col-1, .body-modalx .col-10, .body-modalx .col-11, .body-modalx .col-12, .body-modalx .col-2, .body-modalx .col-3, .body-modalx .col-4, .body-modalx .col-5, .body-modalx .col-6, .body-modalx .col-7, .body-modalx .col-8, .body-modalx .col-9, .body-modalx .col-auto, .body-modalx .col-lg, .body-modalx .col-lg-1, .body-modalx .col-lg-10, .body-modalx .col-lg-11, .body-modalx .col-lg-12, .body-modalx .col-lg-2, .body-modalx .col-lg-3, .body-modalx .col-lg-4, .body-modalx .col-lg-5, .body-modalx .col-lg-6, .body-modalx .col-lg-7, .body-modalx .col-lg-8, .body-modalx .col-lg-9, .body-modalx .col-lg-auto, .body-modalx .col-md, .body-modalx .col-md-1, .body-modalx .col-md-10, .body-modalx .col-md-11, .body-modalx .col-md-12, .body-modalx .col-md-2, .body-modalx .col-md-3, .body-modalx .col-md-4, .body-modalx .col-md-5, .body-modalx .col-md-6, .body-modalx .col-md-7, .body-modalx .col-md-8, .body-modalx .col-md-9, .body-modalx .col-md-auto, .body-modalx .col-sm, .body-modalx .col-sm-1, .body-modalx .col-sm-10, .body-modalx .col-sm-11, .body-modalx .col-sm-12, .body-modalx .col-sm-2, .body-modalx .col-sm-3, .body-modalx .col-sm-4, .body-modalx .col-sm-5, .body-modalx .col-sm-6, .body-modalx .col-sm-7, .body-modalx .col-sm-8, .body-modalx .col-sm-9, .body-modalx .col-sm-auto, .body-modalx .col-xl, .body-modalx .col-xl-1, .body-modalx .col-xl-10, .body-modalx .col-xl-11, .body-modalx .col-xl-12, .body-modalx .col-xl-2, .body-modalx .col-xl-3, .body-modalx .col-xl-4, .body-modalx .col-xl-5, .body-modalx .col-xl-6, .body-modalx .col-xl-7, .body-modalx .col-xl-8, .body-modalx .col-xl-9, .body-modalx .col-xl-auto {
	    position: relative !important;
	    width: 100% !important;
	    min-height: 1px !important;
	    padding-right: 15px !important;
	    padding-left: 15px !important;
	}

	.body-modalx .col-3 {
	    -ms-flex: 0 0 25% !important;
	    flex: 0 0 25% !important;
	    max-width: 25% !important;
	}

	.body-modalx .col-9 {
	    -ms-flex: 0 0 75% !important;
	    flex: 0 0 75% !important;
	    max-width: 75% !important;
	}

	.body-modalx .col-12 {
	    -ms-flex: 0 0 100% !important;
	    flex: 0 0 100% !important;
	    max-width: 100% !important;
	}

	.body-modalx .form-check {
	    position: relative !important;
	    display: block  !important;
	    margin-bottom: .5rem !important;
	}

	.body-modalx .form-check-label {
		padding: 0px !important;
	    padding-left: 1.25rem !important;
	    margin-bottom: 0 !important;
	}

	.body-modalx .form-check-input:only-child {
	    position: static !important;
	}

	.body-modalx input[type="checkbox"], input[type="radio"] {
	    box-sizing: border-box !important;
	    padding: 0 !important;
	}

	.body-modalx .form-check-input {
	    position: absolute;
	    margin-top: .25rem !important;
	    margin-left: -1.25rem !important;
	}

	.body-modalx  .col-form-label {
	    padding-top: calc(.5rem - 1px * 2) !important;
	    padding-bottom: calc(.5rem - 1px * 2) !important;
	    margin-bottom: 0 !important;
	}

	.body-modalx label {
	    display: inline-block !important;
	    font-weight: 400 !important;
	    margin-bottom: .5rem !important;
	    text-transform: none !important;
	}

	.body-modalx [role="button"], .body-modalx a, .body-modalx area, .body-modalx button, .body-modalx input, .body-modalx label, .body-modalx select, .body-modalx summary, .body-modalx textarea {
	    -ms-touch-action: manipulation !important;
	    touch-action: manipulation !important;
	}
	.body-modalx .form-control {
	    display: block !important;
	    width: 100% !important;
	    padding: .5rem .75rem !important;
	    font-size: 1rem !important;
	    line-height: 1.25 !important;
	    color: #495057 !important;
	    background-color: #fff !important;
	    background-image: none !important;
	    background-clip: padding-box !important;
	    border: 1px solid rgba(0,0,0,.15) !important;
	    border-radius: .25rem !important;
	    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s !important;
	}
	.body-modalx button, .body-modalx input {
	    overflow: visible !important;
	}
	.body-modalx button, .body-modalx input, .body-modalx optgroup, .body-modalx select, .body-modalx textarea {
	    margin: 0 !important;
	    font-family: inherit !important;
	    font-size: inherit !important;
	    line-height: inherit !important;
	}

	.body-modalx .text-muted {
	    color: #868e96 !important !important;
	}

	.body-modalx .small, .body-modalx small {
	    font-size: 80% !important;
	    font-weight: 400 !important;
	}

	.body-modalx .btn-outline-secondary:hover {
	    color: #fff !important;
	    background-color: #868e96 !important;
	    border-color: #868e96 !important;
	}
	.body-modalx .btn:focus, .body-modalx .btn:hover {
	    text-decoration: none !important;
	}
	.body-modalx [type="reset"], .body-modalx [type="submit"], .body-modalx button, .body-modalx html .body-modalx [type="button"] {
	    -webkit-appearance: button !important;
	}
	.body-modalx .btn-outline-secondary {
	    color: #868e96 !important;
	    background-color: transparent !important;
	    background-image: none !important;
	    border-color: #868e96 !important;
	} 
	.body-modalx .btn {
	    display: inline-block !important;
	    font-weight: 400 !important;
	    text-align: center !important;
	    white-space: nowrap !important;
	    vertical-align: middle !important;
	    -webkit-user-select: none !important;
	    -moz-user-select: none !important;
	    -ms-user-select: none !important;
	    user-select: none !important;
	    border: 1px solid transparent !important;
	        border-top-color: transparent !important;
	        border-right-color: transparent !important;
	        border-bottom-color: transparent !important;
	        border-left-color: transparent !important;
	    padding: .5rem .75rem !important;
	    font-size: 1rem !important;
	    line-height: 1.25 !important;
	    border-radius: .25rem !important;
	    transition: all .15s ease-in-out !important;
	    min-width: 0px !important;
	}

	.body-modalx button, .body-modalx select {
	    text-transform: none !important;
	}

	.body-modalx button, .body-modalx input {
	    overflow: visible !important;
	}

	.body-modalx .btn-outline-primary {
	    color: #007bff !important;
	    background-color: transparent !important;
	    background-image: none !important;
	    border-color: #007bff !important;
	}
	.body-modalx form {
		margin-bottom: 0px !important;
	}
	/*/*/
</style>