<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://codemage.com/
 * @since      1.0.0
 *
 * @package    Iboostify
 * @subpackage iboostify/admin
 */


/**
 * option name for the iboostify account
 */
global $iboostify_account_option_name;
$iboostify_account_option_name = 'iboostify_account_option_name';


/**
 * save iboostify best sellers as an wp option
 * 
 * @param  array  $post - post data
 * @return array
 */

require 'vendor/autoload.php';
use \Httpful\Request;
function save_iboostify_account(array $post=[]) {

	if (!$post || empty($post) ) 
		throw new Exception("Error Processing Request");
		
	try {
		//verify user in ibootify server
		$url  = 'http://iboostify.dev/api/workshop/check-user';
		$body = '{"email": "'. $post['username'] . '","password": "' . $post['password'] . '"}';
		$response = Request::post($url)
		    ->sendsJson()
		    ->body($body)
		    ->send();
		$response = json_decode($response);

		if (isset($response->error)) {
			$status = false;
			$message = $response->error;
		} else {
			//save details
			global $iboostify_account_option_name;

			$iboostify_account 							= [];
			$iboostify_account['username'] 				= ( isset($post['username']) ? $post['username'] : '');
			$iboostify_account['password'] 				= ( isset($post['password']) ? $post['password'] : '');
			$iboostify_account['user_info']				=  $response->data->user_info;
			$iboostify_account['subscription_details'] 	=  $response->data->subscription_details;
			$iboostify_account['event_data'] 			=  $response->data->event_data;
		
			update_option($iboostify_account_option_name, $iboostify_account);
			$status = true;
			$message = 'Authentication Success.';
		}

	} catch (Exception $e) {
		$status = false;
		$message = $e->getMessage();
	}

	return compact('status', 'message');

} //save_iboostify_account()

/**
 * get the iboostify best sellers
 * 
 * @return array|false
 */
function get_iboostify_account() {

	global $iboostify_account_option_name;

	$iboostify_account = get_option($iboostify_account_option_name);

	if ( !$iboostify_account )
		return [];
	
	return $iboostify_account;

} // iboostify_account()


function save_iboostify_attendee(array $post=[]) {

	if (!$post || empty($post) ) 
		throw new Exception("Error Processing Request");
		
	try {

		$iboostify_setting = get_iboostify_account();
		$post['owner_email'] = $iboostify_setting['username'];
		$post['owner_password'] = $iboostify_setting['password'];
		//save attendee to iboostify server
		$url  = 'http://iboostify.dev/api/workshop/add-attendee';
		$body = json_encode($post);
		$response = Request::post($url)
		    ->sendsJson()
		    ->body($body)
		    ->send();
		$response = json_decode($response);

		if (isset($response->error)) {
			$status = false;
			$message = $response->error;
		} else {
			$status = true;
			$message = $response->data;
		}

	} catch (Exception $e) {
		$status = false;
		$message = $e->getMessage();
	}

	return compact('status', 'message');

} //save_iboostify_account()







