<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://codemage.com/
 * @since      1.0.0
 *
 * @package    Iboostify
 * @subpackage iboostify/admin
 */


/**
 * option name for the iboostify account
 */
global $iboostify_account_option_name;
$iboostify_account_option_name = 'iboostify_account_option_name';


/**
 * save iboostify best sellers as an wp option
 * 
 * @param  array  $post - post data
 * @return array
 */
function save_iboostify_account(array $post=[]) {

	if (!$post || empty($post) ) 
		return [];

	//check if account is registered in ibootify

	//create http post request to iboostify

	//if user is registered save the credentials

	global $iboostify_account_option_name;

	$iboostify_account = [];
	$iboostify_account['username'] = ( isset($post['username']) ? $post['username'] : '');
	$iboostify_account['password'] = ( isset($post['password']) ? $post['password'] : '');
	

	try {
		update_option($iboostify_account_option_name, $iboostify_account);
		return $data;
	} catch (Exception $e) {
		return [];
	}

} //save_iboostify_account()

/**
 * get the iboostify best sellers
 * 
 * @return array|false
 */
function get_iboostify_account() {

	global $iboostify_account_option_name;

	$iboostify_account = get_option($iboostify_account_option_name);

	if ( !$iboostify_account )
		return [];
	
	return $iboostify_account;

} // iboostify_account()







