<?php

/**
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://codemage.com/
 * @since      1.0.0
 *
 * @package    Iboostify
 * @subpackage Iboostify/admin/partials
 */


?>
<script type="text/javascript">
   
</script>

<div id="iboostify-account">
    <div class="panel panel-default">
    <!-- Default panel contents -->
    <div class="panel-heading">Event list</div>

    <!-- Table -->
    <table class="table table-striped">
      <thead>
        <th>#</th>
        <th>Event Name</th>
        <th>Event Location</th>
        <th>Event Event Date</th>
        <th>Shortcode</th>
      </thead>
      <tbody>
        <?php $counter = 1; foreach ($iboostify_setting['event_data'] as $key => $event):?>
          <?php $event_location = explode('|',$event->event_location_date); ?>
          <tr align="center">
            <td> <?= $counter ?> </td>
            <td> <?= $event->event_name ?> </td>
            <td> <?= $event_location[1] ?> </td>
            <td> <?= $event_location[2] ?> </td>
            <td> [iboostify_user_event event_id="<?= $event->event_id ?>"] </td>
          </tr>
        <?php $counter ++; endforeach;?>
      </tbody>
    </table>
  </div>
    
</div>