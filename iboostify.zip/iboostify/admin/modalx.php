<?php include 'modalx_css.php' ?>
<a data-id="" class="modalx-slideDown_open btn btn-info btn-sm botao-controle btn-modal hidden" id="event_modal" href="#modalx-slideDown">Modal</a>
<div id="modalx-slideDown" class="body-modalx" style="width: 100%;">
	<h3 class="text-center"><i class="fa fa-cube"></i><br><span class="txt-destaque1"><?= $event->event_name ?></span><hr></h3>
		<form>
			<div class="container">
				<input type="hidden" name="tags" id="tags" value="<?= $event->tags ?>">
				<input type="hidden" name="affiliate" id="affiliate" value="<?= $user_iboostify_data['user_info']->scraper_affiliate_number ?>">
				<div class="form-group row">
				  <label for="first_name" class="col-3 col-form-label">First Name</label>
				  <div class="col-9">
				    <input class="form-control" type="text" name="first_name" id="first_name" placeholder="Enter First Name">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="last_name" class="col-3 col-form-label">Last Name</label>
				  <div class="col-9">
				    <input class="form-control" type="text" name="last_name" id="last_name" placeholder="Enter Last Name">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="email" class="col-3 col-form-label">Email</label>
				  <div class="col-9">
				    <input class="form-control" type="text" name="email" id="email" placeholder="Enter Email">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="mobile_number" class="col-3 col-form-label">Mobile Number</label>
				  <div class="col-9">
				    <input class="form-control" type="text" name="mobile_number" id="mobile_number" placeholder="Mobile Number">
				  </div>
				</div>
				<br>
				<p class="h5"><small class="text-muted"><strong>Choose Your Most Convenient Session: </strong></small></p>
				<div class="row">
					<div class="col">
						<?= $event->html ?>
					</div>

				</div>
			</div>
		</form>
	<br>
	<button type="button" class="modalx-slideDown_close  btn btn-outline-secondary">Close</button>
	<button type="button" class="btn btn-outline-primary pull-right">Submit</button>
</div>
<?php include 'modalx_js.php' ?>