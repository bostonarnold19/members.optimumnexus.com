<?php include 'modalx_css.php' ?>
<a data-id="" class="modalx-slideDown_open btn btn-info btn-sm botao-controle btn-modal hidden" id="event_modal" href="#modalx-slideDown">Modal</a>
<div id="modalx-slideDown" class="body-modalx" style="width: 100%;">
	<h3 class="text-center"><i class="fa fa-cube"></i><br><span class="txt-destaque1"><?= $event->event_name ?></span><hr></h3>
	<form action="<?= esc_url( admin_url('admin-post.php') );  ?>" method="post" role="form" id="form-iboostify-add-attendee"> 
		<div class="container">
			<input type="hidden" name="action" value="iboostify_attendee">
			<input type="hidden" name="redirect_url" value="<?= home_url(add_query_arg(null, null)); ?>">
    		<input type="hidden" name="type" value="update-or-create" id="type">
			<input type="hidden" name="tags" id="tags" value="<?= $event->tags ?>">
			<input type="hidden" name="event_id" id="event_id" value="<?= $event->event_id ?>">
			<input type="hidden" name="address1" id="address1" value="123 Main Street">
			<input type="hidden" name="address2" id="address2" value="">
			<input type="hidden" name="state" id="state" value="">
			<input type="hidden" name="city" id="city" value="<?= $event_location[1] ?>">
			<input type="hidden" name="zip" id="zip" value="12345">
			<input type="hidden" name="affiliate" id="affiliate" value="<?= $user_iboostify_data['user_info']->scraper_affiliate_number ?>">
			<input type="hidden" name="api_token" id="api_token" value="<?= $user_iboostify_data['user_info']->api_token ?>">
			<div class="form-group row">
			  <label for="first_name" class="col-3 col-form-label">First Name</label>
			  <div class="col-9">
			    <input class="form-control" type="text" name="first_name" id="first_name" placeholder="Enter First Name" required>
			  </div>
			</div>
			<div class="form-group row">
			  <label for="last_name" class="col-3 col-form-label">Last Name</label>
			  <div class="col-9">
			    <input class="form-control" type="text" name="last_name" id="last_name" placeholder="Enter Last Name" required>
			  </div>
			</div>
			<div class="form-group row">
			  <label for="email" class="col-3 col-form-label">Email</label>
			  <div class="col-9">
			    <input class="form-control" type="text" name="email" id="email" placeholder="Enter Email" required>
			  </div>
			</div>
			<div class="form-group row">
			  <label for="mobile_number" class="col-3 col-form-label">Mobile Number</label>
			  <div class="col-9">
			    <input class="form-control" type="text" name="phone" id="phone" placeholder="Mobile Number" required>
			  </div>
			</div>
			<br>
			<p class="h5"><small class="text-muted"><strong>Choose Your Most Convenient Session: </strong></small></p>
			<div class="row">
				<div class="col">
					<?= $event->html ?>
				</div>

			</div>
		</div>
		<br>
		<button type="button" class="modalx-slideDown_close  btn btn-outline-secondary">Close</button>
		<button type="submit" class="btn btn-outline-primary pull-right">Submit</button>
	</form>
</div>
<?php if ( isset($_SESSION['iboostify_message']) && isset($_SESSION['iboostify_message']['message'])) : ?>
<script type="text/javascript">
	swal({
	  title: "<?= $_SESSION['iboostify_message']['header'] ?>",
	  text: "<?= $_SESSION['iboostify_message']['message'] ?>",
	  icon: "<?= $_SESSION['iboostify_message']['type'] ?>",
	  button: "Ok."
	});
</script>
<?php unset($_SESSION['iboostify_message']); endif; ?>
<?php include 'modalx_js.php' ?>