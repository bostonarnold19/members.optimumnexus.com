<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://codemage.com/
 * @since      1.0.0
 *
 * @package    Iboostify
 * @subpackage Iboostify/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Iboostify
 * @subpackage Iboostify/admin
 * @author     Glenn Espejo <glenn.espejo0112@gmail.com>
 */
class Iboostify_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		//  handle the homepage product list order
		add_action( 'admin_post_iboostify_account', [$this, 'post_iboostify_account'] );
		add_action( 'admin_post_iboostify_attendee', [$this, 'post_iboostify_attendee'] );
		add_shortcode( 'iboostify_user_event', [$this, 'iboostify_user_event'] );


	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Iboostify_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Iboostify_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		if ( isset($_GET['page']) && preg_match("~\biboostify\b~", $_GET['page']) ) :
			wp_enqueue_style( $this->plugin_name . '-bootstrap', plugin_dir_url( __FILE__ ) . '../vendor/bootstrap/css/bootstrap.min.css', array(), $this->version, 'all' );
		endif;

		wp_enqueue_style( $this->plugin_name .'-font-awesome', plugin_dir_url( __FILE__ ) . '../vendor/font-awesome/css/font-awesome.min.css', array(), $this->version, 'all' );

		wp_enqueue_style( $this->plugin_name .'-select2', plugin_dir_url( __FILE__ ) . '../vendor/select2/css/select2.min.css', array(), $this->version, 'all' );

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/iboostify-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Iboostify_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Iboostify_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_enqueue_script('jQuery');

		wp_enqueue_script( $this->plugin_name . '-bootstrap', plugin_dir_url( __FILE__ ) . '../vendor/bootstrap/js/bootstrap.min.js', array(), $this->version, false );

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/iboostify-admin.js', array( 'jquery' ), $this->version, false );


		wp_localize_script( $this->plugin_name , 'updateOrCreateUrl', array(
		    'ajax_url' => admin_url( 'admin-ajax.php' )
		));

	}

	public function add_plugin_admin_menu() {

	    /*
	     * Add a settings page for this plugin to the Settings menu.
	     *
	     * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
	     *
	     *        Administration Menus: http://codex.wordpress.org/Administration_Menus
	     *
	     */

	   
	    add_menu_page( 'Iboostify Setup', 'Iboostify', '', $this->plugin_name);

    	add_submenu_page( $this->plugin_name, 'Iboostify', 'Iboostify', 'manage_options', $this->plugin_name.'-account', array($this, 'display_plugin_iboostify_setup_page') );

    	// wp_enqueue_media();

    	remove_filter( 'the_content', 'wpautop' );
    	
    	add_action( 'wp_ajax_post_update_or_create', [$this, 'post_update_or_create'] );
	}

	 /**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	 
	public function add_action_links( $links ) {
	    /*
	    *  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
	    */
	   $settings_link = array(
	    '<a href="' . admin_url( 'admin.php?page=' . $this->plugin_name . '-account' ) . '">' . __('Account', $this->plugin_name) . '</a>',
	   );
	   return array_merge(  $settings_link, $links );

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_setup_page() {
	    include_once( 'partials/account/iboostify-admin-display.php' );
	}

	/**
	 * Render the settings hompage page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_iboostify_setup_page() {
	    include_once( 'partials/account/iboostify-admin-display.php' );
	}



	public function add_meta_host_url_on_head() {
		echo '<meta name="host" value="">';
	}


	/**
	 * handle the slider update or create form
	 * 
	 */
	public function post_iboostify_account() {

		if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

		$redirect_url = sanitize_text_field( isset($_POST['redirect_url']) ? $_POST['redirect_url'] : '');

		$return = save_iboostify_account($_POST);
		
		session_start();
		if ( $return['status'] ) {
			$_SESSION['iboostify_message'] = ['message'=> $return['message'], 'type' => 'success', 'header' => 'Well done!'];
		} else {
			$_SESSION['iboostify_message'] = ['message'=> $return['message'], 'type' => 'danger', 'header' => 'Oh snap!'];
		}

		wp_redirect( $redirect_url );
		return;

	} // post_iboostify_settings()

	public function iboostify_user_event( $attributes ) {
		if(isset($attributes['event_id']) && $attributes['event_id']) {
			
			$event_id 				= $attributes['event_id'];
			$user_iboostify_data 	= get_iboostify_account();
			$event = [];

			foreach ($user_iboostify_data['event_data'] as $key => $value) {
				if ($value->event_id == $event_id) {
					$event = $value;
					$event_location = explode('|',$event->event_location_date); 
					break;
				}
			}
			
			if ($event)
				include('modalx.php');	
		}
	}

	public function post_iboostify_attendee() {

		if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

		$redirect_url = sanitize_text_field( isset($_POST['redirect_url']) ? $_POST['redirect_url'] : '');
		$return = save_iboostify_attendee($_POST);
	

		session_start();

		if ( $return['status'] ) {
			$_SESSION['iboostify_message'] = ['message'=> $return['message'], 'type' => 'success', 'header' => 'Well done!'];
		} else {
			$_SESSION['iboostify_message'] = ['message'=> $return['message'], 'type' => 'error', 'header' => 'Oh snap!'];
		}

		wp_redirect( $redirect_url );
		return;

	} // post_iboostify_settings()


} // class iboostify_Admin
